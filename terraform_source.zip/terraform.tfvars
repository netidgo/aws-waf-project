region              = "ap-northeast-2"
project_name        = "netid"
vpc_cidr            = "172.16.0.0/16"
azs                 = ["ap-northeast-2a", "ap-northeast-2c"]
public_key_material = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC4PjT4jI2+LVYBc7T72NNqKlg93xd+i7TD1WFr+xv0AABSRRlP1VDo5ePIV7U8bV0mEqPkgKLQNC8jrORKpXzYX4YNWIU60WGfsAMHOqI47ZX5q4LtDBQfoE64jFA3VOgRm2Jj9djXD5AHpYeSvyY2Zsy+OvAn5ZWFH/0LdJPucis/rurbVMA2obaVNOk8t2JpB6zU3XwE80d3v4mWoFWetEB9Kg1tX6xo6dSr1PSIOZac8pO1ZBB6owKdkGZpo2nxxQQmmqenSge1RdLvIBGVgla4RptXDNyTuCdgWjt4q2wML/RkmfGjjMfDq15NPp7EmxxMpt4Uv1AtHmGIVKQ9 rsa-key-20261111"
web_ami             = "ami-0131b10cfa2943e15"
openvpn_ami         = "ami-0f42c79eb0c2339c9"
db_name             = "webDB"
user_name           = "root"
db_instance_class   = "db.t3.micro"
db_engine_version   = "8.4.11"
user_data           = <<-EOT
  #!/bin/bash
  yum install -y httpd php php-mbstring php-pdo php-mysqlnd php-gd wget unzip
  wget -O /tmp/frontend_source.zip https://github.com/netidgo/aws-waf-project/raw/refs/heads/main/frontend_source.zip
  unzip -o /tmp/frontend_source.zip -d /var/www/html/
  systemctl start httpd & systemctl enable httpd
  EOT
